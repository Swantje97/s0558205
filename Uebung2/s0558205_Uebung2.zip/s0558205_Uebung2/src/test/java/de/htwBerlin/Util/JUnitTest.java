package de.htwBerlin.Util;

import de.htwBerlin.Model.User;
import de.htwBerlin.Model.Chat;
import org.junit.Before;
import org.junit.Test;
import java.util.List;

import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

public class JUnitTest {

    Util util = new Util();
    User testUser1 = new User("Max","Passw0rd",new ArrayList<>(0));
    User testUser2 = new User("John","Ohdear12",new ArrayList<>(0));
    User participant = new User("Lisa", "pAssw3rd",new ArrayList<>(0));
    List <User> participants = new ArrayList<>();

    @Before
    public void setUp(){
        util.saveUser(testUser1);
        util.saveUser(testUser2);
        util.saveUser(participant);
        participants.add(participant);
    }
    @Test
    public void testRegisterUser(){
        assertEquals(false, util.registerUser("Max", "Passw0rd"));
        assertEquals(false, util.registerUser("Max", "Passw0rd2"));
        assertTrue(util.registerUser("Jenny", "pAssw0rd"));
        assertEquals(0, util.findByUserName("Jenny").getChatList().size());
        assertTrue(util.isUsernameExistsInDB("Jenny"));
    }

    //Test of saveUser isUsernameExistentsInDB and findUserByName
    @Test
    public void testIsUserSavedInDBCorretly (){
        assertEquals(false, util.isUsernameExistsInDB("Berry"));
        User testUser3 = new User("Berry","Pass1worD",new ArrayList<>(0));
        util.saveUser(testUser3);
        assertTrue(util.isUsernameExistsInDB("Berry"));
        assertEquals(0, util.findByUserName("John").getChatList().size());
    }

    @Test
    public void testChatroomParticipantsSavedinListCorrectly(){
        User userInList = new User ("UserInList", "UserinL1st",new ArrayList<>(0));
        assertEquals(2,util.saveUser(Arrays.asList(testUser1,userInList)).size());
    }



    @Test
    public void testNewChatroom(){
        util.openNewChatRoom("Hello World", testUser1,participants);
        assertEquals(new Chat("Hello World", testUser1,participants), util.openNewChatRoom("Hello World", testUser1, participants));
        assertEquals(2, util.findByUserName("Lisa").getChatList().size());
    }

    @Test
    public void testFindChatroomByUserAndChatName(){
        util.openNewChatRoom("ChatRoom", testUser2,participants);
        assertEquals(null, util.findChatRoomByUserAndChatName("John", null));
        assertEquals(new Chat("ChatRoom", testUser2,participants) , util.findChatRoomByUserAndChatName("John", "ChatRoom"));
    }


    @Test
    public void testPasswordValidation(){
        assertEquals(true, util.isUserNameOrPasswordValid("Passw0rd"));
        assertEquals(true, util.isUserNameOrPasswordValid("Passw!rd"));
        assertEquals(false, util.isUserNameOrPasswordValid("passw0rd"));
        assertEquals(false, util.isUserNameOrPasswordValid("Password"));
        assertEquals(false, util.isUserNameOrPasswordValid("Passw0d"));
        assertEquals(false, util.isUserNameOrPasswordValid("12345678"));
    }

    @Test
    public void testLogin(){
        util.saveUser(testUser1);
        assertEquals(true, util.login("Max","Passw0rd"));
        assertEquals(false, util.login("Lisa", "1Password"));
    }

    @Test
    public void testAddMockChatsToUser(){

        util.addMockChatsToUser("John", "MockChatRoom",testUser1, participants);
        assertEquals(false, util.findByUserName("John").getChatList().contains("MockChatRoom"));
    }

    @Test
    public void testGetChatRoomsForUser(){
        util.saveUser(testUser1);
        assertEquals(Arrays.asList(), util.getChatRoomsForUser("Max"));
    }

    @Test
    public void testAddMessageToChatRoom(){
        util.saveUser(testUser1);
        util.addMessageToChatRoom("Max",null, "Wuzzuuup");
    }

    @Test
    public void testGetAllNewChatMessages(){
       util.openNewChatRoom("ThisIsAChat", testUser1, participants);
        Chat chat = util.findChatRoomByUserAndChatName("Max", "ThisIsAChat");
       assertEquals(chat.getMessages().stream().filter(chatMessage -> chatMessage.getCreationDate().isAfter(LocalDateTime.now()))
               .collect(Collectors.toList()), util.getAllNewChatMessages("Max","ThisIsAChat",  LocalDateTime.now()));
    }

    @Test
    public void testRemoveUserFromDB(){
        util.removeUserFromDB("Max");
        assertEquals(false, util.isUsernameExistsInDB("Max"));

    }


}
