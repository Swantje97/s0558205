package de.htwBerlin.Util;

import de.htwBerlin.Model.Chat;
import de.htwBerlin.Model.ChatMessage;
import de.htwBerlin.Model.User;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Data
public class Util {

    //User DB
    private Map<String, User> userDB = new HashMap<>(0);

    /**
     * This method checks if a user name or password is valid
     * the input should be at least 8 characters long
     * have to have one low case, upper case and special char
     * @param value
     * @return boolean
     */
    public boolean isUserNameOrPasswordValid(String value){
        boolean upperCase = false;
        boolean lowerCase = false;
        boolean minLength = false;
        boolean special = false;

        if(value.length() >= 8){
            minLength = true;
        }
        for (char c : value.toCharArray()) {
            if(Character.isUpperCase(c)){
                upperCase = true;
            }
            if(Character.isLowerCase(c)){
               lowerCase = true;
            }
            if(!Character.isLetter(c)){
                special = true;
            }
            if(upperCase && lowerCase && minLength && special){
                return true;
            }
        }

        return false;
    }

    /**
     * chacks if the user exists in DB
     * @param username
     * @return boolean
     */
    public boolean isUsernameExistsInDB(String username){
         return userDB.containsKey(username);
    }

    /**
     * gives the user from the DB
     * @param userName
     * @return
     */
    public User findByUserName(String userName){
        return userDB.get(userName);
    }

    /**
     * saves User Object in the DB
     * @param user
     * @return
     */
    public User saveUser(User user){
        return userDB.put(user.getUserName(), user);
    }

    /**
     * save a list of User Objects in the DB
     * @param users
     * @return
     */
     public List<User> saveUser(List<User> users){
        List<User> res = new ArrayList<>(0);
        for (User user : users) {
            res.add(saveUser(user));
        }
        return res;
    }

    /**
     * finds a chat room by user name and chat name
     * if a chat room was not find a NULL will be returned
     * @param userName
     * @param chatName
     * @return
     */
    public Chat findChatRoomByUserAndChatName(String userName, String chatName){
        List<Chat> chatList = findByUserName(userName).getChatList();
        if (chatList != null) {
            for (Chat chat : chatList) {
                if (chat.getName().equals(chatName)) {
                    return chat;
                }
            }
        }
        return null;
    }


    /**
     * register user in the DB when not exists.
     * @param username
     * @param password
     * @return user successfully saved = true, else false
     */
    public boolean registerUser(String username, String password){
        if(!isUsernameExistsInDB(username)){
            User user = new User(username, password, new ArrayList<>(0));
            saveUser(user);
            return true;
        } else {
            return false;
        }
    }

    /**
     * If the user exists in the DB and the saved user name and password were
     * given a True will be returned.
     * @param username
     * @param password
     * @return boolean
     */
    public boolean login(String username, String password){
        if(userDB.containsKey(username)){
            return userDB.get(username).getPassword().equals(password);
        }
        return false;
    }

    /**
     * removes user from DB
     * @param username
     */
    public void removeUserFromDB(String username){
        userDB.remove(username);
    }

    public void addMockChatsToUser(String username, String chatRoomName, User admin, List <User> participants){
        userDB.get(username).getChatList().add(new Chat(chatRoomName, admin, participants));
    }

    /**
     * gets the ChatRooms of a user
     * @param username
     * @return
     */
    public List<Chat> getChatRoomsForUser(String username){
        if(userDB.containsKey(username)){
           return userDB.get(username).getChatList();
        } else {
            return new ArrayList<>(0);
        }
    }

    /**
     * opens a new chat room
     * @param chatName
     * @param admin
     * @param participants
     * @return
     */
    public Chat openNewChatRoom(String chatName, User admin, List<User> participants){
        Chat chat = new Chat(chatName, admin, participants);
        admin.addChatRoomToUser(chat);
        for (User participant : participants) {
            participant.addChatRoomToUser(chat);
        }
        saveUser(admin);
        saveUser(participants);
        return chat;
    }

    /**
     * adds a message to chat room
     * @param from
     * @param chatName
     * @param content
     * @return
     */
    public List<ChatMessage> addMessageToChatRoom(String from, String chatName, String content){
        Chat chatRoom = findChatRoomByUserAndChatName(from, chatName);
        User user = findByUserName(from);
        if(chatName != null && chatRoom != null){
            ChatMessage chatMessage = new ChatMessage(content, user, LocalDateTime.now());
            List<ChatMessage> messages = chatRoom.getMessages();
            messages.add(chatMessage);
            return messages;
        }
        return new ArrayList<>(0);
    }

    /**
     * Gets all messages in a chat room that are later the the given timeStamp
     * @param username
     * @param chatRoom
     * @param timeStamp
     * @return
     */
    public List<ChatMessage> getAllNewChatMessages(String username, String chatRoom, LocalDateTime timeStamp){
        Chat chat = findChatRoomByUserAndChatName(username, chatRoom);
        return chat.getMessages().stream().filter(chatMessage -> chatMessage.getCreationDate().isAfter(timeStamp))
                .collect(Collectors.toList());
    }
}
