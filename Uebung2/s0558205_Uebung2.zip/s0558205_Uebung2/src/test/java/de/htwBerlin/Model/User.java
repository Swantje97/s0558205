package de.htwBerlin.Model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.util.ArrayList;
import java.util.List;

@Data
@AllArgsConstructor
public class User {

    private String userName;
    private String password;
    private List<Chat> chatList;


    //für JUnit tests ueber allArgsConstructor
//    public User(String userName, String password, List<Chat> chatList) {
//        this.userName = userName;
//        this.password = password;
//        this.chatList = chatList;
//    }

    public boolean addChatRoomToUser(Chat chatRoom){
        if(this.chatList == null){
            this.chatList = new ArrayList<>(0);

        }
        return  this.chatList.add(chatRoom);
    }

   /* public List<Chat> getChatList() {
        return this.chatList;
    }

    public String getUserName() {
        return this.userName;
    }

    public Object getPassword() {
        return this.password;
    }*/
}
