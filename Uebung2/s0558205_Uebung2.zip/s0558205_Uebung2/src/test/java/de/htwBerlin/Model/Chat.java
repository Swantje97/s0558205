package de.htwBerlin.Model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;


@Data
@AllArgsConstructor
@NoArgsConstructor
public class Chat {

    private String name;
    private User admin;
    private List<User> participants;
    private List<ChatMessage> messages;

    public Chat(String chatRoomName, User admin, List<User> participants){
        this.name = chatRoomName;
        this.admin = admin;
        this.participants = participants;
        messages = new ArrayList<>(0);
    }

    /*public Object getName() {
        return this.name;
    }

    public List<ChatMessage> getMessages() {
        return this.messages;
    }*/
}
