package de.htwBerlin.Model;

import lombok.AllArgsConstructor;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
public class ChatMessage {

    private String content;
    private User from;
    private LocalDateTime creationDate;

    public LocalDateTime getCreationDate(){
        return this.creationDate;
    }
}
